
-- !! use "telnetserv.lua" and "webserver.lua" as tcp server example !!
